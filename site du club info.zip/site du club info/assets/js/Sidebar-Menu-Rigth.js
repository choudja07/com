// SIDEBAR
function sidebarOpen() { 
    $('#sidebarSensors').css('display','block')    
}
function sidebarClose() {
    $('#sidebarSensors').css('display','none')
}
